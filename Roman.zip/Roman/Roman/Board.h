#pragma once


#include "Arrow.h"
#include "Barbar.h"
#include "Harp.h"
#include "Note.h"
#include "Wall.h"
#include "Water.h"
#include "Soldier.h"
#include "Menu.h"

#include <map>
#include <memory>
#include <vector>
#include <string>
#include <algorithm>
class Board
{
public:
	Board();
	~Board();
	void startMenu();
	void gameLoop(sf::RenderWindow &window);

private:
	void handleAuto();
	void setLimits( sf::Vector2f &left,  sf::Vector2f&right);
	void handleMovement();
	void CreateShape(const std::vector<std::string> & mat);
	void handlePlayer(Direction_t Left);
	const bool onGround(const sf::Vector2f & pos)const;
	void noteShotings();
	const bool noteReleased();
	void nextlevel(sf::RenderWindow &win);
	void replay(sf::RenderWindow &win);
	void restartlevel(sf::RenderWindow &win);
	void shotingBuffer();

	std::shared_ptr<Soldier> m_player;
	std::vector<std::vector<std::string>> m_levelMap;//level map.
	unsigned int m_numOfLifes;
	std::map<std::pair<float,float>, std::shared_ptr<Object>> m_mapPoints;
	std::map<int, std::shared_ptr<Harp>> m_enemies;
	sf::Time m_noteTimer;
	unsigned int m_currentLevel;
	Menu m_menu;
	sf::Vector2f m_limits;
	sf::Texture m_background;
	sf::Sound m_snd;
	sf::Sound m_jumpsnd;

};


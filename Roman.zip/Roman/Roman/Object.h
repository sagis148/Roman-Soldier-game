#pragma once

#include <SFML\Graphics.hpp>
#include "ReSources.h"

const int SIZE = 40;

class Arrow;
class Barbar;
class Dynamic;
class Harp;
class Human;
class Note;
class ReFill;
class Soldier;
class Stati;
class Trap;
class Wall;
class Water;
class Weapon;



class Object: public sf::Sprite
{
public:
	Object();
	virtual ~Object();

	const bool getStatus()const { return m_dissapear; };//return if the object should be erased from the board
	void setStatus(bool stat) { m_dissapear = stat; };

	virtual bool collide(Object &other)=0;
	virtual bool collide(Wall &other) = 0;
	virtual bool collide(Dynamic &other) = 0;
	virtual bool collide(Human &other) = 0;
	virtual bool collide(Stati &other) = 0;
	virtual bool collide(ReFill &other) = 0;
	virtual bool collide(Trap &other) = 0;
	virtual bool collide(Water &other) = 0;
	virtual bool collide(Weapon &other) = 0;
	virtual bool collide(Arrow &other) = 0;
	virtual bool collide(Barbar &other) = 0;
	virtual bool collide(Harp &other) = 0;
	virtual bool collide(Note &other) = 0;

	virtual void remove() ;

	const bool isStatic()  const { return m_static; };
protected:
	bool m_static;

private:
	
	bool m_dissapear = false;// if object can dissapear from the board.
};


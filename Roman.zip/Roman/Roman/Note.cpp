#include "Note.h"
#include "Soldier.h"


Note::Note()
{

	setTextureRect(sf::IntRect{ 200,0,40,40 });
	setScale(0.5, 0.5);
	setColor(sf::Color::Yellow);

	m_damage = 2;

}


Note::~Note()
{
}

bool Note::collide(Object & other)
{
	return other.collide(*this);
}

bool Note::collide(Wall & other)
{
	return true;
}

bool Note::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Note::collide(Human & other)
{
	return other.collide(*this);
}

bool Note::collide(Stati & other)
{
	return true;
}




bool Note::collide(Water & other)
{
	return true;
}

bool Note::collide(Barbar & other)
{
	return true;
}

bool Note::collide(Harp & other)
{
	return true;
}

bool Note::collide(Soldier & other)
{
	setStatus(true);
	other.setTextureRect(sf::IntRect{ 800,other.getTextureRect().top,80,80 });
	other.decreaseEnergy(m_damage);
	return true;

}

void Note::remove()
{

	if (Soldier::getSoldierPos().x > getPosition().x) {
		if(Soldier::getSoldierPos().y- m_enemyPos.y>20)
		    move(sf::Vector2f{ SPEED/2,-(SPEED - 3) });
		else
			move(sf::Vector2f{ SPEED/2,-(SPEED - 1) });
	}
	if (Soldier::getSoldierPos().x <= getPosition().x) {

		if (getPosition().y - Soldier::getSoldierPos().y>20)
			move(sf::Vector2f{ -SPEED/2,-(SPEED - 3) });
		else
			move(sf::Vector2f{ -SPEED/2,-(SPEED - 1) });

	}
}



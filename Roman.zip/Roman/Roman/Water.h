#pragma once


#include "Stati.h"

class Water:public Stati
{
public:
	Water();
	~Water();

	virtual bool collide(Object &other);

	virtual bool collide(Dynamic &other);
	virtual bool collide(Human &other);
	

	
	virtual bool collide(Weapon &other);
	virtual bool collide(Arrow &other);
	virtual bool collide(Barbar &other);
	
	virtual bool collide(Soldier &other);
private:

};


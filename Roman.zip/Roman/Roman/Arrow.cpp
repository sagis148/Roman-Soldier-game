#include "Arrow.h"

#include "Human.h"
#include "Stati.h"
#include "Barbar.h"
#include "Harp.h"

Arrow::Arrow()
{
	m_damage =2;
	setTextureRect(sf::IntRect{ 40,0,40,10 });
	setScale(0.5, 0.5);
	
}


Arrow::~Arrow()
{
}

bool Arrow::collide(Object & other)
{
	return other.collide(*this);
}

bool Arrow::collide(Wall & other)
{
	
	setStatus(true);
	return true;

}

bool Arrow::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Arrow::collide(Human & other)
{
	return other.collide(*this);
}

bool Arrow::collide(Stati & other)
{
	return other.collide(*this);
}



bool Arrow::collide(Water & other)
{
	setStatus(true);
	return false;
}

bool Arrow::collide(Barbar & other)
{
	
	other.decreaseEnergy(m_damage);
	setStatus(true);
	return true;
}

bool Arrow::collide(Harp & other)
{
	other.setStatus(true);
	setStatus(true);
	return true;
}

bool Arrow::collide(Soldier & other)
{
	return false;
}


#pragma once
#include "Stati.h"

enum kind_t{

	arrow_refill = 0, lifes_refiill = 1, flag = 2
};

class ReFill :
	public Stati
{
public:
	ReFill( kind_t kind=arrow_refill);
	~ReFill();

	const bool isAmmo()const { return m_isAmmo; };
	const kind_t getKind()const { return m_kind; };
	
	virtual bool collide(Object &other);
	virtual bool collide(Dynamic &other);
	virtual bool collide(Human &other);
	virtual bool collide(Weapon &other);
	virtual bool collide(Arrow &other);
	virtual bool collide(Barbar &other);
	virtual bool collide(Soldier &other);

private:
	bool m_isAmmo;//ammo = true , life = false.
	kind_t m_kind;
};


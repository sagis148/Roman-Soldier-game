#pragma once
#include "Object.h"



class Stati :
	public Object
{
public:
	Stati();
	~Stati();
	virtual bool collide(Object &other) = 0;
	virtual bool collide(Wall &other) { return false; };
	virtual bool collide(Dynamic &other) = 0;
	virtual bool collide(Human &other) = 0;
	virtual bool collide(Stati &other) { return false; };
	virtual bool collide(ReFill &other) { return false; };
	virtual bool collide(Trap &other) { return false; };
	virtual bool collide(Water &other) { return false; };
	virtual bool collide(Weapon &other) = 0;
	virtual bool collide(Arrow &other) = 0;
	virtual bool collide(Barbar &other) = 0;
	virtual bool collide(Harp &other) { return false; };
	virtual bool collide(Note &other) {return true;};

private:

};


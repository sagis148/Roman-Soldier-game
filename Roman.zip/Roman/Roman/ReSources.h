#pragma once


#include <SFML\Graphics.hpp>
#include <SFML\Audio.hpp>

class ReSources
{

	///
public:
	static ReSources& instance();
	~ReSources();
///

	const sf::Time getTime() const;
	const sf::Texture & getTexture() const;
	const sf::Font & getFont() const;

	void RestartClock();
	const sf::Texture & getArcherImage() const;
	const sf::Texture & getBarbarImage() const;
	const sf::SoundBuffer & getShootingsound() const { return m_Shootingsound; };
	const sf::SoundBuffer & getjumpsound() const { return m_jumpsound; };
private:
	ReSources();
	ReSources(const ReSources&) = delete;
	ReSources& operator=(const ReSources&) = delete;


	sf::Clock m_clock;
	sf::Font m_font;
	sf::Texture m_dokpic;
	sf::Texture m_archerpic;
	sf::Texture m_barbarpic;
	sf::SoundBuffer  m_Shootingsound;
	sf::SoundBuffer m_jumpsound;
};

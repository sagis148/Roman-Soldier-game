#include "Dynamic.h"



Dynamic::Dynamic()
{

	m_static = false;
}


Dynamic::~Dynamic()
{
}

void Dynamic::remove()
{
	move(m_dirVec);

}

void Dynamic::setDirection(sf::Vector2f dir)
{
	m_dirVec = dir;
}

const sf::Vector2f Dynamic::getDirection() const
{
	return m_dirVec;
}

void Dynamic::setHeadingDir(Direction_t dir)
{
	m_dir = dir;
}





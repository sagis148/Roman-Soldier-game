#pragma once
#include "Dynamic.h"




class Human :
	public Dynamic
{
public:
	Human(unsigned int lives=0);
	~Human();

	void decreaseEnergy(unsigned int damage);
	void setGround(bool bl) { m_onGround = bl; };
	const bool isOnGround()const { return m_onGround; };
	const unsigned int getEnergy()const { return m_energy; };
	void setOriginalPos(sf::Vector2f pos) { m_originPos = pos; };
	const sf::Vector2f getOriginalPos()const { return m_originPos;};



	virtual bool collide(Object &other) = 0;
	virtual bool collide(Wall &other) = 0;
	virtual bool collide(Dynamic &other) = 0;
	virtual bool collide(Human &other) = 0;
	virtual bool collide(Stati &other) = 0;
	virtual bool collide(ReFill &other) = 0;
	virtual bool collide(Trap &other) = 0;
	virtual bool collide(Water &other) = 0;
	virtual bool collide(Weapon &other) = 0;
	virtual bool collide(Arrow &other) = 0;
	virtual bool collide(Barbar &other) = 0;
	virtual bool collide(Harp &other) = 0;
	virtual bool collide(Note &other) = 0;
	virtual bool collide(Soldier &other) = 0;


	virtual void remove();
protected:
	unsigned int m_energy;
	int speed;//movment speed.
	bool m_onGround;//if a human on the ground.
	sf::Vector2f m_originPos;

};


#include "ReSources.h"



ReSources::ReSources()
{
	if (!m_font.loadFromFile("arial.ttf"))//font.
	{
		perror("load failed");
		exit(0);
	}


	if (!m_dokpic.loadFromFile("symbols.png")) {
		perror("load failed");
		exit(0);
	}
	if (!m_archerpic.loadFromFile("archer.png")) {
		perror("load failed");
		exit(0);
	}
	if (!m_barbarpic.loadFromFile("barbaranimation.png")) {
		perror("load failed");
		exit(0);
	}

	if (!m_Shootingsound.loadFromFile("shooting.wav")) {
		perror("load failed");
		exit(0);
	}
	if (!m_jumpsound.loadFromFile("Jump.wav")) {
		perror("load failed");
		exit(0);
	}
	m_clock.restart();
}



ReSources & ReSources::instance()
{
	static ReSources tone;
	return tone;
}

ReSources::~ReSources()
{


}



const sf::Time ReSources::getTime() const
{
	return m_clock.getElapsedTime();
}

const sf::Texture & ReSources::getTexture() const
{
	return m_dokpic;
}

const sf::Font & ReSources::getFont() const
{
	return m_font;
}


void ReSources::RestartClock()
{
	m_clock.restart();

}

const sf::Texture & ReSources::getArcherImage() const
{
	return m_archerpic;
}

const sf::Texture & ReSources::getBarbarImage() const
{
	return m_barbarpic;
}

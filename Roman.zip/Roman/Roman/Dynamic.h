#pragma once
#include "Object.h"




enum Direction_t {

	Up = 0, Right = 1, Down = 2, Left = 3
};
const float SPEED = 4;

class Dynamic :
	public Object
{
public:
	Dynamic();
	~Dynamic();

	virtual bool collide(Object &other) = 0;
	virtual bool collide(Wall &other) = 0;
	virtual bool collide(Dynamic &other) = 0;
	virtual bool collide(Human &other) = 0;
	virtual bool collide(Stati &other) = 0;
	virtual bool collide(ReFill &other) = 0;
	virtual bool collide(Trap &other) = 0;
	virtual bool collide(Water &other) = 0;
	virtual bool collide(Weapon &other) = 0;
	virtual bool collide(Arrow &other) = 0;
	virtual bool collide(Barbar &other) = 0;
	virtual bool collide(Harp &other) = 0;
	virtual bool collide(Note &other) = 0;

	virtual void remove();
	void setDirection(sf::Vector2f);
	const sf::Vector2f getDirection() const;
	void setHeadingDir(Direction_t dir);
	const Direction_t getHeadingDir()const { return m_dir; };

protected:
	Direction_t m_dir;
	sf::Vector2f m_dirVec;
	sf::Clock m_clock;

};


#pragma once


#include "Human.h"

class Soldier:public Human
{
public:
	Soldier();
	~Soldier();

	void arrowRefill() { m_numOfArrows += 3;};
	void energyRefill() { 
		m_energy = (m_energy + 4 > 10 ? 10:m_energy+4); 
	
	};
	void decreaseArrows() { m_numOfArrows--; };
	const unsigned int getNumOfArrows()const { return m_numOfArrows; };
	void setOccupiedFlag(bool bl) { m_occupiedFlag = bl; }
	const bool occupiedFlag()const { return m_occupiedFlag; };

	virtual bool collide(Object &other) ;
	virtual bool collide(Wall &other) ;
	virtual bool collide(Dynamic &other) ;
	virtual bool collide(Human &other) ;
	virtual bool collide(Stati &other) ;
	virtual bool collide(ReFill &other) ;
	virtual bool collide(Trap &other) ;//
	virtual bool collide(Water &other) ;
	virtual bool collide(Weapon &other) ;
	virtual bool collide(Arrow &other) ;
	virtual bool collide(Barbar &other) ;
	virtual bool collide(Harp &other) ;
	virtual bool collide(Note &other) ;
	virtual bool collide(Soldier &other);

	void changeDir();
	void setTimer();
	virtual void remove();
	static sf::Vector2f getSoldierPos();
private:

	bool m_occupiedFlag = false;
	sf::Time m_jump;//jump limit time
	unsigned  int m_numOfArrows;
	static sf::Vector2f m_pos;
	
	


};


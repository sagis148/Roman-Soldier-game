#include "Trap.h"
#include "Soldier.h"


Trap::Trap()
{


	setTextureRect(sf::IntRect{ 280,0,40,20 });

}


Trap::~Trap()
{
}

bool Trap::collide(Object & other)
{
	return other.collide(*this);
}

bool Trap::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Trap::collide(Human & other)
{
	return other.collide(*this);
}

bool Trap::collide(Weapon & other)
{
	return true;
}

bool Trap::collide(Note & other)
{
	return true;
}

bool Trap::collide(Arrow & other)
{
	return true;
}

bool Trap::collide(Barbar & other)
{
	return true;
}

bool Trap::collide(Soldier & other)
{
	setStatus(true);
	other.decreaseEnergy(3);
	other.setTextureRect(sf::IntRect{ 800,other.getTextureRect().top,80,80 });
	return true;
}



#pragma once
#include "Stati.h"


class Trap :
	public Stati
{
public:
	Trap();
	~Trap();

	virtual bool collide(Object &other) ;
	
	virtual bool collide(Dynamic &other) ;
	virtual bool collide(Human &other) ;
	
	
	virtual bool collide(Weapon &other);
	virtual bool collide(Note &other);
	virtual bool collide(Arrow &other) ;
	virtual bool collide(Barbar &other) ;
	
	virtual bool collide(Soldier &other) ;
private:


};


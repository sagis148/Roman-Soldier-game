#include "Harp.h"
#include "Dynamic.h"
#include "Note.h"
#include "Soldier.h"
#include "Arrow.h"

Harp::Harp()
{

	setTextureRect(sf::IntRect{ 120,0,40,40 });
	m_shoterTimer = ReSources::instance().getTime();
}


Harp::~Harp()
{
}




bool Harp::collide(Object & other)
{
	return other.collide(*this);
}

bool Harp::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Harp::collide(Human & other)
{
	return other.collide(*this);
}

bool Harp::collide(Weapon & other)
{
	return other.collide(*this);
}

bool Harp::collide(Arrow & other)
{
 	setStatus(true);
	other.setStatus(true);
	return true;
}

bool Harp::collide(Barbar & other)
{
	return true;
}

bool Harp::collide(Soldier & other)
{
	setStatus(true);
	
	return true;
}

bool Harp::collide(Note & other)
{
	return true;
}


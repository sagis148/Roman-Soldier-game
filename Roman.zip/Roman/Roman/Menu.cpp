#include "Menu.h"
#include <sstream>


Menu::Menu()
{
	m_arrowsprite.setTexture(ReSources::instance().getTexture());
	m_arrowsprite.setPosition(5,5);
	m_arrowsprite.setTextureRect(sf::IntRect{0,0,40,40});
	
	m_energysprite.setTexture(ReSources::instance().getTexture());
	m_energysprite.setPosition(5,45);
	m_energysprite.setTextureRect(sf::IntRect{ 160,0,40,40 });

	m_charcter.setTexture(ReSources::instance().getTexture());
	m_charcter.setPosition(5, 100);
	m_charcter.setTextureRect(sf::IntRect{ 440,0,40,40 });


}


Menu::~Menu()
{
}

void Menu::draw(sf::RenderWindow & win , int arrows, int lives)
{

	
	sf::RectangleShape rect;
	rect.setPosition(60, 50);
	rect.setSize(sf::Vector2f{ 200,30 });
	rect.setFillColor(sf::Color::Red);
	rect.setOutlineColor(sf::Color::Black);
	rect.setOutlineThickness(2);

	sf::RectangleShape liferect;
	liferect.setSize(sf::Vector2f{ ((float)m_energy/10)*200,30 });
	liferect.setFillColor(sf::Color::Green);
	liferect.setPosition(60, 50);
	sf::Vertex line[] =
	{
		sf::Vertex(sf::Vector2f(80, 50),sf::Color::Black),
		sf::Vertex(sf::Vector2f(80, 80),sf::Color::Black)
	};




	sf::Sprite heart;
	heart.setTexture(ReSources::instance().getTexture());
	heart.setTextureRect(sf::IntRect{ 400,0,40,40 });
	heart.setPosition(50, 100);
	for (int i = 0; i < lives; i++) {
		win.draw(heart);
		heart.move(40, 0);
	}

	sf::Sprite arro;
	arro.setTexture(ReSources::instance().getTexture());
	arro.setTextureRect(sf::IntRect{ 240,0,40,40 });
	arro.setPosition(50,5);
	for (int i = 0; i < arrows; i++) {
		win.draw(arro);
		arro.move(20, 0);
	}
	win.draw(rect);
	win.draw(liferect);
	win.draw(m_arrowsprite);
	win.draw(m_energysprite);
	win.draw(m_charcter);
	for (int i = 0; i < 10;i++) {
		line[0].position=sf::Vector2f{ (float)80+20*i,50 };
		line[1].position = sf::Vector2f{ (float)80 + 20 * i,80 };
		win.draw(line, 2, sf::Lines);
	}
	//win.draw(line, 2, sf::Lines);
}

bool Menu::mainMenu(sf::RenderWindow & window)
{
	{

		sf::Sprite background(m_menupic);
		background.scale(1.3f, 1.0f);

		sf::Text play("Play", ReSources::instance().getFont(), 100);
		sf::Text exit("Exit", ReSources::instance().getFont(), 100);
		play.setPosition(sf::Vector2f{ 300,250 });
		play.setFillColor(sf::Color().Red);
		exit.setPosition(sf::Vector2f{ 300,500 });
		exit.setFillColor(sf::Color().Red);
		while (window.isOpen())
		{
			for (sf::Event event; window.pollEvent(event);)
			{
				switch (event.type)
				{
				case sf::Event::Closed:
					window.close();
					break;

				case sf::Event::MouseButtonPressed:
				{
					sf::Vector2f mouseCoords = window.mapPixelToCoords(
					{ event.mouseButton.x, event.mouseButton.y });
					if (play.getGlobalBounds().contains(mouseCoords)) {
						return true;
					}
					if (exit.getGlobalBounds().contains(mouseCoords)) {
						return false;
					}
				}
				case sf::Event::MouseMoved:
				{
					sf::Vector2f mouseCoords = window.mapPixelToCoords(
					{ event.mouseMove.x, event.mouseMove.y });
					if (play.getGlobalBounds().contains(mouseCoords))
						play.setCharacterSize(150);
					else if (exit.getGlobalBounds().contains(mouseCoords))
						exit.setCharacterSize(150);
					else {
						play.setCharacterSize(100);
						exit.setCharacterSize(100);
					}

				}
				}
			}
			window.clear(sf::Color::Black);
			window.draw(background);
			window.draw(play);
			window.draw(exit);
			window.display();
		}
	}
}

std::string Menu::dtos(double x)
{
	std::stringstream s;
	s << x;
	return s.str();
}

#pragma once

#include "Weapon.h"

class Arrow:public Weapon
{
public:
	Arrow();
	~Arrow();
	virtual bool collide(Object &other) ;
	virtual bool collide(Wall &other) ;
	virtual bool collide(Dynamic &other) ;
	virtual bool collide(Human &other) ;
	virtual bool collide(Stati &other) ;

	
	virtual bool collide(Water &other) ;

	virtual bool collide(Barbar &other) ;
	virtual bool collide(Harp &other) ;
	virtual bool collide(Soldier &other);


private:

};


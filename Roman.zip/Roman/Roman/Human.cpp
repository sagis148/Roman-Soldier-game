#include "Human.h"



Human::Human(unsigned int energy):m_energy(energy)
{

}


Human::~Human()
{
}

void Human::decreaseEnergy(unsigned int damage)
{
	if ((int)(m_energy - damage) < 0) {
		m_energy = 0;
	}
	else {
		m_energy -= damage;
	}
	if (m_energy <= 0) 
	{
		 setStatus(true);
		 m_energy = 0;
	}
}

void Human::remove()
{

	move(m_dirVec);
}

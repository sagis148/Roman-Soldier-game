#include "Weapon.h"



Weapon::Weapon(unsigned int damage):m_damage(damage)
{


}


Weapon::~Weapon()
{
}

void Weapon::remove()
{
	move(m_dirVec);
}

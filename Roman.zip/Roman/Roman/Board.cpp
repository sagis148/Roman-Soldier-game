#include "Board.h"
#include "Trap.h"
#include "ReFill.h"
#include "ReSources.h"
#include <fstream>
#include <iostream>
#include <algorithm>

Board::Board()
{
	if (!m_background.loadFromFile("background.png"))
	{
		perror("load failed");
		exit(0);
	}
	m_currentLevel = 0;
	std::ifstream file(R"(file.txt)");

	if (!file) {
		perror("did not succes");
	}
	int row;
	std::string temp;
	file >> row;
	
	
	getline(file, temp);
	while (!file.eof()) {

		std::vector<std::string> mat;
		mat.clear();

		for (int i = 0;i < row-1;i++) {
			getline(file, temp);
			mat.push_back(temp);
			
		}
		
		m_levelMap.push_back(mat);
		file >> row;
		getline(file, temp);
		getline(file, temp);
	}
	file.close();

	m_noteTimer = ReSources::instance().getTime();
	m_numOfLifes = 3;
}


Board::~Board()
{
}

void Board::startMenu()
{

	sf::RenderWindow window(sf::VideoMode(SIZE * 20, SIZE * 20 + MENUHEIGHT), "Roman soldier", sf::Style::Close);
	m_mapPoints.clear();
	if (m_menu.mainMenu(window)) {
		CreateShape(m_levelMap[m_currentLevel]);
		gameLoop(window);
	}
	else {
		return;
	}


}

void Board::gameLoop(sf::RenderWindow &window)
{

	
	window.setFramerateLimit(30);
	sf::Time timer = ReSources::instance().getTime();
	sf::View view;
	view.setCenter(m_player->getPosition());
	window.setView(view);
	sf::View gameView;
	gameView.setViewport(sf::FloatRect{ 0.75f,0.f,0.25f,0.25f });
	view.setViewport(sf::FloatRect{ 0.f,2 / 8.f,1,3/4.f });
	view.setSize(600, 600);
	gameView.setSize(1300, 1300);
	while (window.isOpen() && !m_player->getStatus()&& !m_player->occupiedFlag())
	{
		sf::Vector2i temp{ (int)m_player->getPosition().x, (int)m_player->getPosition().y };
		if (temp.x < 300)
			temp.x = 300;

		if (temp.y < 300)
			temp.y = 300;
		if (temp.y > m_limits.y + SIZE - view.getSize().y / 2)
			temp.y = m_limits.y+SIZE - view.getSize().y / 2;
		if (temp.x > m_limits.x + SIZE - view.getSize().x / 2)
			temp.x = m_limits.x+SIZE - view.getSize().x / 2;

		view.setCenter(sf::Vector2f{ (float)temp.x,(float)temp.y });
		gameView.setCenter(m_player->getPosition());
		noteShotings();
		sf::Time delta = ReSources::instance().getTime() - timer;
		if (delta.asSeconds() > 0.018)
		{
			if (!onGround(m_player->getPosition())) {
				m_player->setGround(false);
				handleAuto();
			}
			else if (onGround(m_player->getPosition())) {
				m_player->setGround(true);
				m_player->setDirection(sf::Vector2f(0, 0));
			}
			handleMovement();
			delta.Zero;
			timer = ReSources::instance().getTime();

		}

		for (sf::Event event; window.pollEvent(event);)
		{
			if (delta.asSeconds() > 0.035) {

				break;
			}
			switch (event.type)
			{
			case sf::Event::Closed:
				window.close();
				break;

			case sf::Event::KeyPressed:
			{
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
				{

					handlePlayer(Left);
				}
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
				{

					handlePlayer(Right);
				}
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
				{
					handlePlayer(Up);
				}
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
				{
					handlePlayer(Down);
					
				}
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
				{
					if (m_player->isOnGround() && m_player->getNumOfArrows()>0) {
						m_player->decreaseArrows();
						auto arrow = std::make_shared<Arrow>();
						if (m_player->getHeadingDir() == Left) {
							arrow->setTextureRect(sf::IntRect{ 80,0,40,40 });
							arrow->setDirection(sf::Vector2f{ -2 * (SPEED),0 });
							arrow->setPosition(m_player->getPosition() + sf::Vector2f{ -SIZE,(SIZE - 1) / 2 });
						}
						else {
							arrow->setTextureRect(sf::IntRect{ 40,0,40,40 });
							arrow->setDirection(sf::Vector2f{ 2 * (SPEED),0 });
							arrow->setPosition(m_player->getPosition() + sf::Vector2f{ (float)SIZE,(float)(SIZE - 1) / 2 });
						}
						shotingBuffer();
						m_mapPoints[std::make_pair(arrow->getPosition().y, arrow->getPosition().x)] = arrow;
					}
					break;

				}
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
				{
					
					return;
				}
				else
					break;
			}
			}

		}

		window.clear(sf::Color(16, 79, 172));
		window.setView(view);
		sf::Sprite background;
		background.scale(1.5, 1.5);
		background.setTexture(m_background);
		window.draw(background);
		for (auto& runner : m_mapPoints)
			window.draw(*runner.second);
		window.setView(gameView);
		for (auto& runner : m_mapPoints)
			window.draw(*runner.second);
		window.setView(window.getDefaultView());
		m_menu.set(m_player->getEnergy());
		m_menu.draw(window,m_player->getNumOfArrows(), m_numOfLifes);
		window.display();
	}


	if (m_player->getStatus()) {
		--m_numOfLifes;
		if (m_numOfLifes == 0) {
			m_numOfLifes = 3;
			startMenu();
		}
		else {
			restartlevel(window);
		}
		
	}
	else {
		m_numOfLifes++;
		nextlevel(window);
	}
	
	
}

void Board::handleAuto()
{

    if(m_player->getStatus())
		return;
	auto runner = m_mapPoints.find(std::make_pair(m_player->getPosition().y, m_player->getPosition().x));
	m_player->remove();
	
	auto low= m_mapPoints.lower_bound(std::make_pair(m_player->getPosition().y-SIZE, m_player->getPosition().x-SIZE));
	auto high= m_mapPoints.upper_bound(std::make_pair(m_player->getPosition().y+SIZE, m_player->getPosition().x+ SIZE));

	for (auto it = low;it != high;)
	{
		if (runner != it && runner->second->getGlobalBounds().intersects(it->second->getGlobalBounds()))//sprites cillide
		{
			if (runner->second->collide(*it->second)) 
			{

				if (runner->second->getStatus())//if the player destroyed.
				{
					m_mapPoints.emplace(std::make_pair(m_player->getPosition().y, m_player->getPosition().x), runner->second);
					runner->second = NULL;
					m_mapPoints.erase(runner);
					
					return;
				}
				else if (it->second->getStatus())//if the it were destroy
				{

					auto temp = it;
					++it;
					m_mapPoints.erase(temp);
					m_mapPoints.emplace(std::make_pair(m_player->getPosition().y, m_player->getPosition().x), runner->second);
					runner->second = NULL;
					auto eraser = runner;
					m_mapPoints.erase(eraser);
					runner = m_mapPoints.find(std::make_pair(m_player->getPosition().y, m_player->getPosition().x));
					break;
				}


			}
		}
		else {

			++it;
			if (it == high) {
				sf::Vector2f checker{ runner->first.second,runner->first.first };
				if (checker != m_player->getPosition()) {
					m_mapPoints.emplace(std::pair<float, float>(m_player->getPosition().y, m_player->getPosition().x), m_player);
					runner->second = NULL;
					auto eraser = runner;
					m_mapPoints.erase(eraser);
				}
				break;

			}

		}


	}


}

void Board::setLimits( sf::Vector2f & left,  sf::Vector2f & right)
{

	while (1) {
		if (onGround(left)) {
			auto it = m_mapPoints.find(std::make_pair(left.y, left.x));
			if (it == m_mapPoints.end())
				left = left + sf::Vector2f{ -SIZE,0 };
			else
				break;
		}
		else
			break;


	}
	left = left;
	while (1) {
		if (onGround(right)) {
			auto it = m_mapPoints.find(std::make_pair(right.y, right.x));
			if (it == m_mapPoints.end())
				right = right + sf::Vector2f{ (float)SIZE,0 };
			else
				break;
		}
		else
			break;


	}

}

void Board::handleMovement()
{

	if (m_player->getStatus())
		return;
	auto player= m_mapPoints.find(std::make_pair(m_player->getPosition().y, m_player->getPosition().x));

	for (auto runner = m_mapPoints.begin();runner != m_mapPoints.end(); )
	{
		
		if (runner != player && !runner->second->isStatic())// check if runner is not stati or player.
		{
			runner->second->remove();
			auto doubleMover = runner->second;
			auto low = m_mapPoints.lower_bound(std::make_pair(runner->second->getPosition().y - SIZE, runner->second->getPosition().x - SIZE));
			auto high = m_mapPoints.upper_bound(std::make_pair(runner->second->getPosition().y + SIZE, runner->second->getPosition().x + SIZE));

			for (auto it = low;it != high;)
			{
				if (runner != it && runner->second->getGlobalBounds().intersects(it->second->getGlobalBounds()))//sprites cillide
				{
					if (runner->second->collide(*it->second))
					{

						if (runner->second->getStatus() && it->second->getStatus()) {
							if(it!=player)
							     m_mapPoints.erase(it);
							m_mapPoints.erase(runner);
							return;

						}
						else if (runner->second->getStatus())//if the player destroyed.
						{

							auto temp = runner;
							++runner;
							m_mapPoints.erase(temp);
							
							break;
						}
						else if (it->second->getStatus())//if the it were destroy
						{

							auto temp = it;
							++it;
							if (temp == player) {
								m_mapPoints.emplace(std::make_pair(runner->second->getPosition().y, runner->second->getPosition().x), runner->second);
								runner->second = NULL;
								m_mapPoints.erase(runner);
								return;
							}
							m_mapPoints.erase(temp);
							m_mapPoints.emplace(std::make_pair(runner->second->getPosition().y, runner->second->getPosition().x), runner->second);
							
							auto eraser = runner;
							runner++;
							eraser->second = NULL;
							m_mapPoints.erase(eraser);
							//runner = m_mapPoints.find(std::make_pair(m_player->getPosition().y, m_player->getPosition().x));
							break;
						}
						++it;

					}
					else 
					   ++it;
				}
				else {

					++it;
					if (it == high) {
						sf::Vector2f checker{ runner->first.second,runner->first.first };
						if (checker != runner->second->getPosition()) {
							m_mapPoints.emplace(std::make_pair(runner->second->getPosition().y, runner->second->getPosition().x), runner->second);
							runner->second = NULL;
							auto temp = runner;
							++runner;
							if (doubleMover == runner->second)
								++runner;
							m_mapPoints.erase(temp);
						}
						else
							++runner;
					}

				}


			}


		}
		else {
			++runner;
		}
		

	}
}

void Board::CreateShape(const std::vector<std::string>& mat)
{


	std::vector<sf::Vector2f> points;
	for (size_t i = 0; i < mat.size(); i++)
	{
		for (size_t j = 0; j < mat[i].size(); j++)
		{
			sf::Vector2f square = { (float)j*SIZE,(float)(i*SIZE + MENUHEIGHT) };
			switch (mat[i][j])
			{
			case 'S':
			{
				auto newobj = std::make_shared<Soldier>();
				newobj->setPosition(square);
				newobj->setOriginalPos(square);
				m_player = newobj;
				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
			case 'B'://Barbar
				
			{

				points.emplace_back(square);

				break;
			}
			case 'H'://Harp
				
			{
				auto newobj = std::make_shared<Harp>();
				newobj->setPosition(square);

				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				m_enemies[m_enemies.size() + 1] = newobj;
				

				break;
			}
			case 'F'://flag
			{
				auto newobj = std::make_shared<ReFill>(flag);
				newobj->setPosition(square);
				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
			case 'A'://Arrow
			{
				auto newobj = std::make_shared<Arrow>();
				newobj->setPosition(square);


				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
			case 'W'://Water
			{
				auto newobj = std::make_shared<Water>();
				newobj->setPosition(square);
		

				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
			case 'T'://Trap
				
			{
				auto newobj = std::make_shared<Trap>();
				newobj->setPosition(square + sf::Vector2f{0,SIZE/2});
			
				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
			case 'M'://Ammo
			{
				
				auto newobj = std::make_shared<ReFill>(arrow_refill);
				newobj->setPosition(square);
	

				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
			case 'L'://Life
			{
				auto newobj = std::make_shared<ReFill>(lifes_refiill);
				newobj->setPosition(square);
				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
			case 'X'://Wall
							{
				auto newobj = std::make_shared<Wall>();
				newobj->setPosition(square);

				m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
				break;
			}
				
			}
		}
	}


	for (size_t i = 0;i < points.size();++i) {
		auto newobj = std::make_shared<Barbar>();
		newobj->setPosition(points[i]);
		sf::Vector2f left = points[i], right = points[i];
		setLimits(left, right);
		newobj->setLimits(left.x, right.x);
		m_mapPoints[std::make_pair(newobj->getPosition().y, newobj->getPosition().x)] = newobj;
	}

	auto temp = m_mapPoints.end();
	--temp;
	m_limits = temp->second->getPosition();
}

void Board::handlePlayer(Direction_t dir)
{

	switch (dir) 
	{
	    case Left:
		{
			sf::Vector2f temp = m_player->getDirection();
			if (Left != m_player->getHeadingDir()) {
				m_player->changeDir();
			}
			m_player->setHeadingDir(Left);
			m_player->setDirection(sf::Vector2f(-SPEED, 0));
			handleAuto();
			m_player->setDirection(temp);
			break;
		}
		case Right:
		{
			sf::Vector2f temp = m_player->getDirection();
			if (Right != m_player->getHeadingDir()) {
				m_player->changeDir();
			}
			m_player->setHeadingDir(Right);
			m_player->setDirection(sf::Vector2f(SPEED,0));
			handleAuto();
			m_player->setDirection(temp);
			break;
		}
		case Up:
		{
			if (onGround(m_player->getPosition())) {
				m_player->setTimer();
				m_jumpsnd.setBuffer(ReSources::instance().getjumpsound());
				m_jumpsnd.play();
				m_player->setGround(false);
				handleAuto();
			}
			break;
		}
		case Down:
		{
			
			break;
		}

	}


}

const bool Board::onGround(const sf::Vector2f & pos) const
{
	
	auto lowy = m_mapPoints.lower_bound(std::make_pair<float,float>(pos.y+SIZE, pos.x-SIZE));
	auto upy = m_mapPoints.upper_bound(std::make_pair<float, float>(pos.y + SIZE, pos.x + 2*SIZE));

	for (auto runner = lowy;runner != upy;++runner)
	{
		bool one = runner->second->getPosition().y == pos.y+SIZE;
		bool sec = (runner->second->getPosition().x < pos.x + SIZE-(2*SPEED))&& (runner->second->getPosition().x > pos.x - SIZE+ (2*SPEED));
		bool third = typeid(Wall) == typeid(*runner->second);
		if (one&&sec&&third)
			return true;
		
	}
	return false;



}

void Board::noteShotings()
{

	bool entered=false;
	for (auto it = m_mapPoints.begin(); it != m_mapPoints.end(); ++it)
	{

		if (typeid(*it->second)==typeid(Harp)&& noteReleased()) {

			auto newnote = std::make_shared<Note>();
			newnote->setPosition(it->second->getPosition() + sf::Vector2f{ 0,- (SPEED*2) });
			newnote->enemyPosition(m_player->getPosition());
			m_mapPoints[std::make_pair(newnote->getPosition().y, newnote->getPosition().x)] = newnote;
			entered = true;
		}



	}
	if (entered)
	      m_noteTimer = ReSources::instance().getTime();


}

const bool Board::noteReleased() 
{
	if ((ReSources::instance().getTime() - m_noteTimer).asSeconds() > 6)
	{
		
		return true;

	}
	else
		return false;

}

void Board::nextlevel(sf::RenderWindow & win)
{

	sf::Time delta = ReSources::instance().getTime();
	m_currentLevel++;
	sf::Text txt;
	m_mapPoints.clear();	
    txt.setFont(ReSources::instance().getFont());
	txt.setCharacterSize(30);
	txt.setPosition(150, 200);
	txt.setFillColor(sf::Color::Red);

	while (win.isOpen() && (ReSources::instance().getTime() - delta).asSeconds() < 2) {
		if (m_currentLevel == m_levelMap.size()){
			txt.setString("Congratulations! you finshed the game!!!!!");
		}
		else {
			txt.setString("Congratulations get ready to the next level!");
		}
		win.clear();
		win.draw(txt);
		win.display();
	}
	if (m_currentLevel == m_levelMap.size()) {
		win.close();
	}
	else {
		CreateShape(m_levelMap[m_currentLevel]);
		gameLoop(win);
	}
}

void Board::replay(sf::RenderWindow & win)
{


}

void Board::restartlevel(sf::RenderWindow & win)
{
	m_player->setStatus(false);
	auto pl = m_mapPoints.find(std::make_pair(m_player->getPosition().y, m_player->getPosition().x));
	m_player->setPosition(m_player->getOriginalPos());
	m_mapPoints.emplace(std::make_pair(m_player->getPosition().y, m_player->getPosition().x), pl->second);
	pl->second = NULL;
	m_mapPoints.erase(pl);
	m_player->decreaseEnergy(m_player->getEnergy() - 10);
	sf::Time delta = ReSources::instance().getTime();
	while ((ReSources::instance().getTime() - delta).asSeconds() < 2) {


	}
	gameLoop(win);
	
}

void Board::shotingBuffer()
{
	sf::Time t = sf::seconds(4);

	
	m_snd.setBuffer(ReSources::instance().getShootingsound());
	//m_snd.setVolume(70);
	m_snd.play();
	m_snd.setPlayingOffset(t);
	

}



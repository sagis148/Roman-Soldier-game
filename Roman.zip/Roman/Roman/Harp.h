#pragma once



#include "Stati.h"



class Harp:public Stati
{
public:
	Harp();
	~Harp();

	static bool shootingtime();

	virtual bool collide(Object &other) ;
	
	virtual bool collide(Dynamic &other) ;
	virtual bool collide(Human &other) ;

	virtual bool collide(Weapon &other) ;
	virtual bool collide(Arrow &other);
	virtual bool collide(Barbar &other) ;
	virtual bool collide(Soldier &other);
	virtual bool collide(Note &other) ;

private:
	sf::Time m_shoterTimer;
	

};


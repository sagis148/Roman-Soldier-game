#pragma once

#include "Weapon.h"


class Note: public Weapon
{
public:
	Note();
	~Note();
	void enemyPosition(sf::Vector2f pos) { m_enemyPos = pos; };



	virtual bool collide(Object &other);
	virtual bool collide(Wall &other);
	virtual bool collide(Dynamic &other);
	virtual bool collide(Human &other);
	virtual bool collide(Stati &other);
	

	virtual bool collide(Water &other);
	
	
	virtual bool collide(Barbar &other);
	virtual bool collide(Harp &other);

	virtual bool collide(Soldier &other);
	virtual void remove();


private:
	sf::Vector2f m_enemyPos;
};


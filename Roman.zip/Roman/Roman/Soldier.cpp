#include "Soldier.h"
#include "ReFill.h"
#include "Arrow.h"
#include "Harp.h"
#include "Note.h"
#include "Trap.h"

Soldier::Soldier()
{
	m_energy = 10;
	m_numOfArrows = 4;
	setDirection(sf::Vector2f{ 0,0 });
	
	m_jump = ReSources::instance().getTime();
	setTexture(ReSources::instance().getArcherImage());
	setTextureRect(sf::IntRect{ 10,0,60,80 });
	setScale(0.5, 0.5);
	
}
sf::Vector2f Soldier::m_pos = sf::Vector2f{ 0,0 };

Soldier::~Soldier()
{


}

bool Soldier::collide(Object & other)
{
	return other.collide(*this);

}

bool Soldier::collide(Wall & other)
{
	move(-getDirection());
	if (getDirection() == sf::Vector2f{ 0,-4 })
		setDirection(sf::Vector2f{ 0,4 });
	return false;
}

bool Soldier::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Soldier::collide(Human & other)
{
	return other.collide(*this);
}

bool Soldier::collide(Stati & other)
{
	return other.collide(*this);
}

bool Soldier::collide(ReFill & other)
{
	other.setStatus(true);
	if (other.getKind() == arrow_refill)
		arrowRefill();
	else if (other.getKind() == lifes_refiill)
		energyRefill();
	else {
		setOccupiedFlag(true);
	}
	return true;

}

bool Soldier::collide(Trap & other)
{
	
	other.setStatus(true);
	decreaseEnergy(3);
	setTextureRect(sf::IntRect{ 800,getTextureRect().top,80,80 });
	return true;
}

bool Soldier::collide(Water & other)
{

	setStatus(true);
	return true;
}


void Soldier::setTimer()
{
	m_clock.restart();
	m_dirVec=sf::Vector2f{ 0,-SPEED };


}

void Soldier::remove()
{

	if (m_clock.getElapsedTime().asSeconds() > 1.55 &&!m_onGround &&getDirection().x==0){
		
		m_dirVec = sf::Vector2f(0, SPEED);
	}
	
	sf::IntRect t=getTextureRect();

	if(m_onGround)
	   setTextureRect(sf::IntRect{ (getTextureRect().left+80)%640,getTextureRect().top,getTextureRect().width,getTextureRect().height });
	else
		setTextureRect(sf::IntRect{ (250) % 640,getTextureRect().top,getTextureRect().width,getTextureRect().height });
	
	m_pos = getPosition();
	move(m_dirVec);

}

sf::Vector2f Soldier::getSoldierPos()
{
	return m_pos;
}
bool Soldier::collide(Weapon & other)
{
	return other.collide(*this);
}

bool Soldier::collide(Arrow & other)
{
	return false;
}

bool Soldier::collide(Barbar & other)
{
	setStatus(true);
	return true;
}

bool Soldier::collide(Harp & other)
{
	other.setStatus(true);
	return true;
}

bool Soldier::collide(Note & other)
{
	other.setStatus(true);
	decreaseEnergy(other.getDamage());
	setTextureRect(sf::IntRect{ 800,getTextureRect().top,80,80 });
	return true;
}

bool Soldier::collide(Soldier & other)
{
	return true;
}

void Soldier::changeDir()
{
	if (m_dir == Right) {

		setTextureRect(sf::IntRect{ 0,80,80,80 });
	}
	else if (m_dir == Left) {

		setTextureRect(sf::IntRect{ 0,0,80,80 });
	}

}

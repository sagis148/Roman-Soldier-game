#include "Object.h"



Object::Object()
{
	m_dissapear = false;
	setTexture(ReSources::instance().getTexture());
}


Object::~Object()
{
}

void Object::remove()
{

	move(0, 0);
}

#include "ReFill.h"
#include "Soldier.h"



ReFill::ReFill(kind_t kind)
{
	if(kind == arrow_refill)
	    setTextureRect(sf::IntRect{ 0,0,40,40 });
	else if(kind==lifes_refiill)
	   setTextureRect(sf::IntRect{ 160,0,40,40 });
	else {
		setTextureRect(sf::IntRect{ 480,0,40,40 });
	}
	m_kind = kind;

}


ReFill::~ReFill()
{
}

bool ReFill::collide(Object & other)
{
	return other.collide(*this);
}

bool ReFill::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool ReFill::collide(Human & other)
{
	return other.collide(*this);
}

bool ReFill::collide(Weapon & other)
{
	return true;
}

bool ReFill::collide(Arrow & other)
{
	return true;
}

bool ReFill::collide(Barbar & other)
{
	return true;
}

bool ReFill::collide(Soldier & other)
{
	setStatus(true);
	if (m_kind==arrow_refill)
		other.arrowRefill();
	else if(m_kind == arrow_refill)
		other.energyRefill();
	else {
		other.setOccupiedFlag(true);
	}
	return true;
}


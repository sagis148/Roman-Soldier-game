#pragma once
#include "Dynamic.h"



class Weapon :
	public Dynamic
{
public:
	Weapon(unsigned int damage=0);
	~Weapon();

	const unsigned getDamage()const { return m_damage; };

	virtual bool collide(Object &other) = 0;
	virtual bool collide(Wall &other) = 0;
	virtual bool collide(Dynamic &other) = 0;
	virtual bool collide(Human &other) = 0;
	virtual bool collide(Stati &other) = 0;
	virtual bool collide(ReFill &other) {return true;};
	virtual bool collide(Trap &other) { return true; };
	virtual bool collide(Water &other) = 0;
	virtual bool collide(Weapon &other) {return true;};
	virtual bool collide(Arrow &other) { return true; };
	virtual bool collide(Barbar &other) = 0;
	virtual bool collide(Harp &other) = 0;
	virtual bool collide(Note &other) { return true; };
	virtual void remove();

protected:
	unsigned m_damage;

	sf::Time m_flick;//whan the weapon hits the target.
	sf::Time m_cycleTime;//time that till dissapearance.

};


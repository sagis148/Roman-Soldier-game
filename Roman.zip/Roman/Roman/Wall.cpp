#include "Wall.h"
#include "Arrow.h"
#include "Barbar.h"
#include "Soldier.h"
Wall::Wall():Stati()
{

	setTextureRect(sf::IntRect{ 320,0,40,40 });

}


Wall::~Wall()
{
}

bool Wall::collide(Object & other)
{
	return other.collide(*this);
}

bool Wall::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Wall::collide(Human & other)
{
	return other.collide(*this);
}

bool Wall::collide(Weapon & other)
{
	return other.collide(*this);
}

bool Wall::collide(Arrow & other)
{
	other.setStatus(true);
	return true;
}

bool Wall::collide(Barbar & other)
{
	other.move(-other.getDirection());
	other.setDirection(-other.getDirection());
	return false;
}

bool Wall::collide(Soldier & other)
{
	other.move(-other.getDirection());
	if (other.getDirection() == sf::Vector2f{ 0,-4 })
		other.setDirection(sf::Vector2f{ 0,4 });

	return false;
}



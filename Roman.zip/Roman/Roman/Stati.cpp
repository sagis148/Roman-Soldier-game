#include "Stati.h"



Stati::Stati()
{

	m_static = true;
}


Stati::~Stati()
{


}

#include "Water.h"
#include "Arrow.h"
#include "Soldier.h"
Water::Water()
{

	setTextureRect(sf::IntRect{ 360,0,40,40 });



}


Water::~Water()
{
}

bool Water::collide(Object & other)
{
	return other.collide(*this);
}

bool Water::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Water::collide(Human & other)
{
	return other.collide(*this);
}

bool Water::collide(Weapon & other)
{
	return other.collide(*this);
}

bool Water::collide(Arrow & other)
{
	other.setStatus(true);
	return false;
}

bool Water::collide(Barbar & other)
{
	return false;
}

bool Water::collide(Soldier & other)
{
	other.setStatus(true);
	return true;
}



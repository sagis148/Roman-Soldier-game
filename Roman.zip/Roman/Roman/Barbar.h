#pragma once

#include "Human.h"




class Barbar:public Human
{
public:
	Barbar();
	~Barbar();
	void setLimits(float left, float right) { m_leftLimit = left;m_rightLimit = right; };

	virtual bool collide(Object &other) ;
	virtual bool collide(Wall &other) ;
	virtual bool collide(Dynamic &other) ;
	virtual bool collide(Human &other) ;
	virtual bool collide(Stati &other) ;
	virtual bool collide(ReFill &other) ;
	virtual bool collide(Trap &other) ;
	virtual bool collide(Water &other) ;
	virtual bool collide(Weapon &other) ;
	virtual bool collide(Arrow &other) ;
	virtual bool collide(Barbar &other) ;
	virtual bool collide(Harp &other) ;
	virtual bool collide(Note &other) ;
	virtual bool collide(Soldier &other);
	virtual void remove();

private:
	float m_leftLimit, m_rightLimit;

};


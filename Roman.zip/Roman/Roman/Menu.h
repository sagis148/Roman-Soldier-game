#pragma once
#include "ReSources.h"

#include <SFML\Graphics.hpp>
const int MENUHEIGHT = 100;

class Menu
{
public:
	Menu();
	~Menu();
	void draw(sf::RenderWindow &win, int arrows, int lives);
	void set(unsigned int ener) { m_energy = ener; };
	bool Menu::mainMenu(sf::RenderWindow & window);
	

private:
	std::string dtos(double x);
	unsigned int m_energy,m_arrows,m_lifes;
	sf::Time m_time;
	sf::Text m_txt;
	sf::RectangleShape m_rect;
	sf::Texture m_menupic;
	sf::Sprite m_energysprite;
	sf::Sprite m_arrowsprite;
	sf::Sprite m_charcter;

};


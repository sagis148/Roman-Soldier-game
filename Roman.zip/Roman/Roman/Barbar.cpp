#include "Barbar.h"
#include "Trap.h"
#include "Arrow.h"
#include "Soldier.h"

Barbar::Barbar()
{
	m_energy = 4;
	setDirection(sf::Vector2f{ SPEED,0 });
	setTexture(ReSources::instance().getBarbarImage());
	setTextureRect(sf::IntRect{ 0,0,80,80 });
	setScale(0.5, 0.5);


}


Barbar::~Barbar()
{
}

bool Barbar::collide(Object & other)
{
	return other.collide(*this);
}

bool Barbar::collide(Wall & other)
{
	move(-m_dirVec);
	m_dirVec = -m_dirVec;
	return false;
}

bool Barbar::collide(Dynamic & other)
{
	return other.collide(*this);
}

bool Barbar::collide(Human & other)
{
	return other.collide(*this);
}

bool Barbar::collide(Stati & other)
{
	return other.collide(*this);
}

bool Barbar::collide(ReFill & other)
{
	return true;
}

bool Barbar::collide(Trap & other)
{
	move(-m_dirVec);
	m_dirVec = -m_dirVec;
	return false;
}

bool Barbar::collide(Water & other)
{
	move(-m_dirVec);
	m_dirVec = -m_dirVec;
	return false;
}

bool Barbar::collide(Weapon & other)
{
	return other.collide(*this);
}

bool Barbar::collide(Arrow & other)
{
	other.setStatus(true);
	decreaseEnergy(other.getDamage());
	return true;
}

bool Barbar::collide(Barbar & other)
{
	return true;
}

bool Barbar::collide(Harp & other)
{
	return true;
}

bool Barbar::collide(Note & other)
{
	return true;
}

bool Barbar::collide(Soldier & other)
{
	other.setStatus(true);
	return true;
}

void Barbar::remove()
{
	if (getPosition().x <= m_leftLimit + SIZE) {
		setTextureRect(sf::IntRect{ 0,0,80,80 });
		setDirection(sf::Vector2f{ SPEED,0 });
	}
	else if (getPosition().x >= m_rightLimit - SIZE)
	{
		setTextureRect(sf::IntRect{ 0,80,80,80 });
	    setDirection(sf::Vector2f{ -SPEED,0 });
    }
	else {
		setTextureRect(sf::IntRect{ (getTextureRect().left + 320) % 480,getTextureRect().top,getTextureRect().width,getTextureRect().height });
	}


	move(m_dirVec);

}




